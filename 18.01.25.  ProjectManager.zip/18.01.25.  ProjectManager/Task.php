<?php
class Task {
    private $title, $description, $status = "Не выполнено";

    public function __construct($title, $description) {
        $this->title = $title;
        $this->description = $description;
    }

    public function __destruct() {
        echo "Задача '{$this->title}' удалена.\n";
    }

    public function __call($method, $args) {
        $property = strtolower(substr($method, 3));
        if (strpos($method, 'set') === 0) $this->$property = $args[0];
        if (strpos($method, 'get') === 0) return $this->$property ?? null;
    }

    public function __toString() {
        return "Задача: {$this->title} — {$this->status}";
    }
}
?>