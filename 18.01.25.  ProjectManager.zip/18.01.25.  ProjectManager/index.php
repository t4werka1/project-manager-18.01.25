<?php
require 'Project.php';
require 'Task.php';
$project = new Project("Проект");
$task1 = new Task("Задача 1", "Описание 1");
$task2 = new Task("Задача 2", "Описание 2");

$project->addTask($task1);
$project->addTask($task2);

echo $project . "\n"; 
echo $task1 . "\n";   
$task1->setStatus("Выполнено");
echo $task1 . "\n";   
?>